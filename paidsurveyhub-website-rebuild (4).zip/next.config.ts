import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    // Direct browser delivery avoids requiring Netlify's image optimizer.
    unoptimized: true,
    remotePatterns: [
      { protocol: "https", hostname: "images.pexels.com", pathname: "/photos/**" },
    ],
  },
};

export default nextConfig;
