# Deploy PaidSurveyHub on Netlify

PaidSurveyHub is a Next.js App Router application. Netlify automatically uses its current Next.js adapter for Next.js 13.5+ projects, including App Router pages, route handlers, and `next/image` optimization.

## Netlify build settings

The included `netlify.toml` configures these settings:

- **Build command:** `npm run build`
- **Publish directory:** `.next`
- **Node version:** `20`

Do not add a single-page-app redirect such as `/* /index.html 200`. It overrides Next.js routing and prevents App Router pages and `/api/*` routes from working correctly.

## Guide images

Guide and homepage photos are delivered from configured HTTPS image URLs. The build does not import any local `public/images` files, so Netlify does not need photo binaries in the Git repository. No image upload or additional Netlify image setting is required.

## Required environment variable for forms

The site content can deploy without a database. Contact messages and newsletter subscriptions need an externally reachable PostgreSQL database.

In Netlify, add this variable under **Project configuration → Environment variables**:

| Name | Value | Required scopes |
| --- | --- | --- |
| `DATABASE_URL` | Your hosted PostgreSQL connection string | **Builds** and **Functions** |

Use a hosted PostgreSQL provider such as Neon, Supabase, Railway, Render, or another provider that accepts connections from Netlify. A local URL such as `postgresql://postgres:postgres@127.0.0.1:5432/app_db` only works on your own computer and cannot be reached by Netlify.

If your provider supplies a pooled/serverless connection string, use that for `DATABASE_URL`. Keep the full connection string private; do not prefix it with `NEXT_PUBLIC_`.

After adding or changing an environment variable, trigger a new Netlify deploy. Environment changes do not modify already deployed functions.

## Database tables

Before using the contact and newsletter forms in production, apply the Drizzle schema to the hosted database:

```bash
DATABASE_URL="your-hosted-postgres-url" npx drizzle-kit push
```

This creates the `contact_messages` and `newsletter_subscriptions` tables used by the forms.

## What happens without a database

The website still builds and serves its guides, articles, SEO pages, images, sitemap, RSS feed, and search. Form endpoints return a clear configuration response until `DATABASE_URL` is supplied.

## Recommended verification after deploy

1. Open the Netlify site URL and check the homepage.
2. Visit an article and confirm images load.
3. Test `/api/health`.
4. Submit the contact form after configuring the database.
5. Subscribe and unsubscribe from the newsletter after applying the schema.
