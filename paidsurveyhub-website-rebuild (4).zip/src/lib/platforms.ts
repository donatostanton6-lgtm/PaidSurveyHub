export type PlatformCategory = "Research" | "Rewards" | "Testing" | "Microtasks" | "Freelancing" | "Cashback";

export type Platform = {
  name: string;
  category: PlatformCategory;
  description: string;
  url: string;
  initials: string;
};

/**
 * Editorial directory only. These are not partnerships, endorsements, or
 * availability guarantees. Visitors should confirm current terms directly.
 */
export const platforms: Platform[] = [
  { name: "Prolific", category: "Research", description: "Research participation platform with study-specific eligibility.", url: "https://www.prolific.com/", initials: "PR" },
  { name: "YouGov", category: "Research", description: "Opinion research and panel opportunities that vary by country.", url: "https://yougov.com/", initials: "YG" },
  { name: "Toluna", category: "Research", description: "Consumer research community with panel-based activities.", url: "https://www.toluna.com/", initials: "TO" },
  { name: "Ipsos iSay", category: "Research", description: "Survey panel operated under Ipsos’ iSay brand.", url: "https://www.ipsosisay.com/", initials: "IS" },
  { name: "LifePoints", category: "Research", description: "Market-research panel with country-specific membership options.", url: "https://www.lifepointspanel.com/", initials: "LP" },
  { name: "ySense", category: "Rewards", description: "Online rewards platform with surveys and published offer terms.", url: "https://www.ysense.com/", initials: "YS" },
  { name: "Swagbucks", category: "Rewards", description: "Rewards platform offering activities and redemption options by region.", url: "https://www.swagbucks.com/", initials: "SB" },
  { name: "Survey Junkie", category: "Research", description: "Survey-focused panel with eligibility and regional requirements.", url: "https://www.surveyjunkie.com/", initials: "SJ" },
  { name: "AttaPoll", category: "Research", description: "Mobile survey platform; availability and payout options can vary.", url: "https://attapoll.com/", initials: "AP" },
  { name: "UserTesting", category: "Testing", description: "User-research platform for feedback on websites and digital products.", url: "https://www.usertesting.com/", initials: "UT" },
  { name: "Respondent", category: "Testing", description: "Research recruitment platform for qualifying study participants.", url: "https://www.respondent.io/", initials: "RE" },
  { name: "Clickworker", category: "Microtasks", description: "Task platform with project, qualification, and location requirements.", url: "https://www.clickworker.com/", initials: "CW" },
  { name: "Amazon Mechanical Turk", category: "Microtasks", description: "Marketplace for tasks with requester-defined access and rules.", url: "https://www.mturk.com/", initials: "MT" },
  { name: "Fiverr", category: "Freelancing", description: "Marketplace for defined digital and professional services.", url: "https://www.fiverr.com/", initials: "FI" },
  { name: "Upwork", category: "Freelancing", description: "Work marketplace for clients and independent professionals.", url: "https://www.upwork.com/", initials: "UP" },
  { name: "Rakuten", category: "Cashback", description: "Shopping rewards service with retailer and regional conditions.", url: "https://www.rakuten.com/", initials: "RA" },
  { name: "TopCashback", category: "Cashback", description: "Cashback service where rates, retailers, and terms can change.", url: "https://www.topcashback.com/", initials: "TC" },
  { name: "Quidco", category: "Cashback", description: "Cashback platform with offers and terms that may be country-specific.", url: "https://www.quidco.com/", initials: "QU" },
  { name: "Ibotta", category: "Cashback", description: "Shopping rewards platform with retailer and location requirements.", url: "https://home.ibotta.com/", initials: "IB" },
  { name: "ShopBack", category: "Cashback", description: "Shopping rewards service with market-specific availability.", url: "https://www.shopback.com/", initials: "SH" },
];

export const platformCategoryClasses: Record<PlatformCategory, string> = {
  Research: "research",
  Rewards: "rewards",
  Testing: "testing",
  Microtasks: "microtasks",
  Freelancing: "freelancing",
  Cashback: "cashback",
};
