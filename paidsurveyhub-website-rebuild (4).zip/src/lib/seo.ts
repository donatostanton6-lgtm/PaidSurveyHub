import type { Metadata } from "next";
import { SITE_URL } from "./content";

export function pageMetadata(title: string, description: string, path = "/"): Metadata {
  const canonical = new URL(path, SITE_URL).toString();
  return {
    title,
    description,
    alternates: { canonical },
    openGraph: { title, description, url: canonical, siteName: "PaidSurveyHub", locale: "en_US", type: "website" },
    twitter: { card: "summary_large_image", title, description },
  };
}
