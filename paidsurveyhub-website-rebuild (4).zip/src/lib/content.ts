import { guideImageByCategory } from "./guide-images";
import { longGuideOverrides } from "./long-guides";

export { guideImageByCategory };

export type Category = {
  slug: "surveys" | "rewards" | "online-earning" | "microtasks" | "cashback" | "personal-finance";
  name: string;
  eyebrow: string;
  summary: string;
  description: string;
  color: string;
  faqs: { question: string; answer: string }[];
};

export type Article = {
  slug: string;
  title: string;
  category: Category["slug"];
  date: string;
  updated?: string;
  minutes: number;
  excerpt: string;
  intro: string;
  keyPoint: string;
  sections: { heading: string; body: string[] }[];
  faq?: { question: string; answer: string }[];
};

export const SITE_URL = "https://paidsurveyhub.com";

export const categories: Category[] = [
  {
    slug: "surveys",
    name: "Paid Surveys",
    eyebrow: "Survey guides",
    summary: "Understand panels, screening, rewards, and survey safety before you join.",
    description: "Paid surveys are research questionnaires where eligible participants can receive points, gift cards, or other rewards. Our guides explain how panels work, why screening happens, where country availability matters, and how to approach privacy with care.",
    color: "blue",
    faqs: [
      { question: "Do paid surveys pay everyone who starts?", answer: "Not always. Many surveys use screening questions to find people who match a particular research need. A screen-out is not necessarily a problem with your account." },
      { question: "Why are surveys different in each country?", answer: "Panels need respondents for specific studies. Local research demand, payment rules, languages, and provider operations can all affect what is available." },
      { question: "What should I check first?", answer: "Read the reward terms, cash-out threshold, privacy notice, country eligibility, and support information before sharing more information than necessary." },
    ],
  },
  {
    slug: "rewards",
    name: "Rewards Programs",
    eyebrow: "Rewards explained",
    summary: "Make sense of points, gift cards, redemption rules, and loyalty terms.",
    description: "Rewards programs can turn qualifying activity into points, discounts, gift cards, or account credit. This section unpacks how balances are earned, what redemption rules can mean, and why expiry policies deserve a careful read.",
    color: "indigo",
    faqs: [
      { question: "Are points the same as cash?", answer: "No. A point value and redemption choices are set by the program and can change. Review the available rewards and any conversion details before participating." },
      { question: "Can reward balances expire?", answer: "Some programs have inactivity or expiry rules, while others do not. The current terms should always be the source of truth." },
      { question: "Why do redemption options vary?", answer: "Programs may offer different payment partners, currencies, or gift cards by region, and availability can change without much notice." },
    ],
  },
  {
    slug: "online-earning",
    name: "Online Earning",
    eyebrow: "Practical opportunities",
    summary: "Realistic context for surveys, freelancing, research studies, testing, and digital services.",
    description: "Online earning opportunities range from occasional surveys to skilled freelance work. We focus on practical trade-offs: eligibility, time, demand, payment terms, and the importance of avoiding promises that sound too good to be true.",
    color: "teal",
    faqs: [
      { question: "Can online tasks replace a full-time income?", answer: "It depends on the work, skills, demand, location, and circumstances. Small-task and reward platforms should not be presented as guaranteed income sources." },
      { question: "What makes an opportunity credible?", answer: "Clear eligibility, transparent terms, understandable payment rules, a real support path, and a privacy policy are useful signals to investigate." },
      { question: "Should I pay to access work?", answer: "Be cautious with upfront-payment requests. Research the company, understand exactly what is being sold, and never share sensitive information casually." },
    ],
  },
  {
    slug: "microtasks",
    name: "Microtasks",
    eyebrow: "Task work basics",
    summary: "Learn the time, qualification, payment, and security realities of small online tasks.",
    description: "Microtasks are small pieces of work that can help train systems, organize information, or check digital content. This section explains task types, qualifications, payment models, realistic time considerations, and account safety.",
    color: "violet",
    faqs: [
      { question: "What is a microtask?", answer: "It is a short, clearly defined task such as categorizing content, checking an address, transcribing a brief item, or completing a research activity." },
      { question: "Are tasks always available?", answer: "No. Task volume depends on platform demand, qualifications, location, language, and quality requirements." },
      { question: "What should I track?", answer: "Keep a simple record of time spent, accepted work, pending balances, and payout rules so you can make informed decisions." },
    ],
  },
  {
    slug: "cashback",
    name: "Cashback",
    eyebrow: "Shopping rewards",
    summary: "See how tracking, exclusions, pending periods, and withdrawals work.",
    description: "Cashback programs may offer a portion of a qualifying purchase back as a reward. Learn how tracking works, why a purchase may not appear immediately, which exclusions matter, and what happens when orders are changed or returned.",
    color: "green",
    faqs: [
      { question: "Is cashback immediate?", answer: "Usually not. Retailers often confirm purchases after a pending period, and programs may have their own withdrawal timetable." },
      { question: "Why was a purchase not tracked?", answer: "Cookie settings, another promotional code, browser extensions, purchase exclusions, and a changed order can all affect tracking. The program’s support process may help clarify a case." },
      { question: "Should cashback change what I buy?", answer: "It is best viewed as a possible extra on planned spending, not as a reason to make an unnecessary purchase." },
    ],
  },
  {
    slug: "personal-finance",
    name: "Personal Finance",
    eyebrow: "Money basics",
    summary: "Clear, general education around budgeting, safety, saving, and everyday money habits.",
    description: "Personal finance content at PaidSurveyHub is general education, not individualized financial advice. Explore practical basics for budgeting, subscriptions, payment safety, understanding fees, and building sustainable money habits.",
    color: "amber",
    faqs: [
      { question: "Is this personal financial advice?", answer: "No. These resources are general educational information. Consider your own circumstances and seek qualified help where appropriate." },
      { question: "What is a good first budgeting step?", answer: "Start by listing what comes in, essential costs, regular commitments, and flexible spending. A simple, honest picture is more useful than a complicated system you will not maintain." },
      { question: "How can I make online payments safer?", answer: "Use unique passwords, enable available account security features, verify merchants independently, and monitor statements for unexpected activity." },
    ],
  },
];

export const categoryBySlug = Object.fromEntries(categories.map((category) => [category.slug, category])) as Record<Category["slug"], Category>;


const surveySections = [
  { heading: "Start with the research process", body: ["Survey panels connect researchers with people who may be relevant to a particular question. A study might look for shoppers in a certain category, people who use a type of device, or residents of a particular place. The panel is not usually choosing a ‘best’ respondent; it is trying to fill a defined sample.", "That is why an invitation is not the same as a completed survey. Screening is a normal part of market research, and a thoughtful approach begins with treating every eligibility question accurately rather than trying to guess the expected answer."] },
  { heading: "Check the practical terms before investing time", body: ["Look for the country list, payout threshold, reward types, account verification rules, and how long a reward may remain pending. A program can be legitimate and still be a poor fit if its redemption options or availability do not match your circumstances.", "Keep your own simple record of completed activities and redemptions. It can make it easier to spot a missing credit, understand your time commitment, and decide whether a particular panel is worth revisiting."] },
  { heading: "Keep personal information proportionate", body: ["A reputable provider should explain what it collects and why. Basic profile questions are common because they help match studies, but sensitive requests deserve more scrutiny. Read the privacy notice and avoid sharing credentials, banking passwords, or identity documents unless the reason and provider are clear.", "Use a strong, unique password and a dedicated email address if that helps you keep invitations organized. These small habits also make it easier to leave a service if you no longer want to use it."] },
];
const rewardSections = [
  { heading: "Understand the unit you are collecting", body: ["A point, credit, or token in a rewards program is not automatically equivalent to cash. The program decides its redemption catalog, exchange relationship, and any conditions attached to a balance. Check the actual rewards you would use before making points your priority.", "Take note of the minimum redemption amount and whether the program shows values consistently. A clearly displayed redemption path makes it easier to compare options without relying on assumptions."] },
  { heading: "Read the rules around time and eligibility", body: ["Programs may set activity requirements, expiry windows, account-location rules, and limits on how rewards can be combined. These conditions are not always prominent in promotional copy, so the terms and FAQ pages are worth a few minutes of attention.", "If a program changes an important term, decide based on the new information rather than on how it worked in the past. Rewards, inventory, and participating partners can change over time."] },
  { heading: "Keep an organized redemption record", body: ["Save confirmation emails and record the date you requested a reward. This is useful when a digital reward is delivered separately or when a program has a stated processing window.", "It is also sensible to redeem according to a program’s rules instead of accumulating a balance indefinitely. This is not a recommendation for every program; it is a reminder to understand the policy that applies to your account."] },
];
const earningSections = [
  { heading: "Separate opportunities by the skill and demand involved", body: ["Online work spans very different activities. Freelance services usually depend on a specific skill and client demand. Research studies and website tests depend on fit. Surveys, cashback, and reward tasks can be occasional extras rather than predictable work.", "Comparing all of these as though they have the same time value leads to poor decisions. Start by identifying what is being asked of you, what qualifications are needed, and what the current terms say about payment."] },
  { heading: "Set expectations before you begin", body: ["No legitimate guide can promise that an opportunity will produce a particular result for everyone. Availability changes with geography, demand, eligibility, and platform policies. Treat earning claims that hide those variables with caution.", "A useful way to evaluate an option is to track the full process: time to qualify, task time, rejected work, pending periods, fees, and payment method. This gives you information grounded in your own experience without assuming results will generalize."] },
  { heading: "Protect the accounts you use", body: ["Use unique passwords and enable multi-factor authentication when it is available. Review what an application or service is requesting before connecting an account or uploading documents.", "A real-looking website alone is not enough. Verify a provider through its own published support channels, read recent terms, and pause if an offer asks for money, credentials, or sensitive personal information without a clear reason."] },
];
const taskSections = [
  { heading: "Know what counts as a microtask", body: ["Microtasks divide a larger project into short actions. Depending on the service, that could mean describing an image, checking a data point, completing a short transcription, testing a flow, or answering a research question.", "The apparent length of a task does not tell the entire story. Instructions, qualification checks, revision requests, and the time spent waiting for work can all affect the real commitment."] },
  { heading: "Read acceptance and quality rules carefully", body: ["Many task platforms use quality checks to protect the usefulness of submitted work. Before starting, look for the reason a task can be rejected, whether there is a review process, and whether examples are provided.", "Do not rush through unclear instructions. It is better to skip a confusing task than to submit work that may be rejected or compromise the quality of your account history."] },
  { heading: "Treat privacy and access with care", body: ["Some tasks involve information that should be handled carefully. Avoid copying data outside the permitted environment, and never use a task as a reason to collect unrelated personal information.", "Availability can also be tied to language, location, device, and completed qualifications. That is normal for this kind of work and should be stated plainly by the platform."] },
];
const cashbackSections = [
  { heading: "Follow the tracking path", body: ["Cashback tracking normally relies on a link or browser session connecting an eligible purchase to a program. The exact method and exclusions are set by the program and retailer. Begin from the advertised route and read the qualifying purchase rules before checkout.", "Do not assume a displayed rate applies to every product. Gift cards, taxes, shipping, coupon codes, subscription renewals, or certain product categories may be excluded. The retailer’s offer detail page is the relevant reference."] },
  { heading: "Expect a pending period", body: ["A tracked purchase can take time to appear and even longer to become withdrawable. Retailers often need to confirm that an order was not canceled, changed, or returned. This can make cashback feel delayed even when tracking has worked as intended.", "Save your order confirmation and the offer details. If a transaction is missing after the stated window, submit a support request with accurate information rather than placing a duplicate order."] },
  { heading: "Use rewards without creating extra spending", body: ["Cashback is most useful when it applies to a planned, eligible purchase. A higher rate does not turn an unnecessary purchase into a saving, and exclusions can change the final outcome.", "Compare the complete offer, including delivery, price, return terms, and the time until payout. A clear record of pending and paid rewards helps keep the benefit in perspective."] },
];
const financeSections = [
  { heading: "Begin with clear information", body: ["General money education is most helpful when it starts with a realistic snapshot. List the money that comes in, essential expenses, regular commitments, and flexible spending. The aim is awareness, not judgment.", "Use a method that is simple enough to revisit. A spreadsheet, a notes app, or a calendar review can work if it helps you notice patterns and make decisions based on current information."] },
  { heading: "Make room for security and fees", body: ["Digital money habits include more than spending categories. Review account alerts, password security, subscription dates, and fees that may apply to an account or transfer. Understanding the terms ahead of time is usually easier than resolving a surprise later.", "When comparing services, look beyond a headline benefit. Exchange rates, withdrawal conditions, account restrictions, and customer support channels are practical details that can matter in everyday use."] },
  { heading: "Use education as a starting point, not a personal plan", body: ["This article provides general information and cannot account for individual income, obligations, laws, taxes, or goals. Important decisions may call for a qualified professional who can consider your specific situation.", "Small, repeatable actions are often more durable than drastic changes. Choose one review habit, write it down, and adjust when your circumstances change."] },
];

const sectionByCategory: Record<Category["slug"], Article["sections"]> = {
  surveys: surveySections, rewards: rewardSections, "online-earning": earningSections, microtasks: taskSections, cashback: cashbackSections, "personal-finance": financeSections,
};

const drafts: Array<Omit<Article, "sections" | "keyPoint" | "faq">> = [
  ["how-paid-surveys-work", "How Paid Surveys Work and What to Expect", "surveys", "2026-01-18", 8, "A clear introduction to panels, invitations, screening, and rewards — without exaggerated expectations.", "Paid surveys can be a useful way to understand consumer research, but they are not a predictable income stream. This guide shows what usually happens from registration through reward redemption."],
  ["are-paid-surveys-worth-your-time", "Are Paid Surveys Worth Your Time?", "surveys", "2026-01-15", 7, "A practical framework for considering time, availability, cash-out rules, and your own priorities.", "Whether a survey is worthwhile depends on more than the reward listed on an invitation. Consider the time involved, how often you qualify, and whether the program’s terms suit your country and preferences."],
  ["how-to-avoid-survey-scams", "How to Avoid Survey Scams", "surveys", "2026-01-12", 9, "Warning signs, verification steps, and safer habits for evaluating survey invitations.", "Survey scams often lean on urgency, unclear payment claims, or requests for information that a legitimate research panel would not need. Learn to slow down and check the details."],
  ["why-you-get-screened-out-of-surveys", "Why You Get Screened Out of Surveys", "surveys", "2026-01-10", 6, "Why eligibility questions exist and what a screen-out can mean in market research.", "Screen-outs are frustrating, but they are usually connected to the narrow audience a study needs. Honest profile information is the best way to approach the process."],
  ["how-survey-rewards-usually-work", "How Survey Rewards Usually Work", "surveys", "2026-01-08", 7, "Points, credits, gift cards, cash options, and withdrawal thresholds explained.", "Survey rewards can be structured in several ways. Understanding conversion, processing, and threshold rules helps you make informed choices before spending time."],
  ["what-to-check-before-joining-a-survey-platform", "What to Check Before Joining a Survey Platform", "surveys", "2026-01-05", 8, "A pre-join checklist for eligibility, privacy, redemption, and customer support.", "A few minutes spent reading a platform’s policies can tell you much more than a headline reward rate. Here is a measured checklist for comparing survey services."],
  ["how-geographic-restrictions-affect-surveys", "How Geographic Restrictions Affect Online Surveys", "surveys", "2025-12-28", 7, "Why country, language, and study demand can change what you see on a survey panel.", "Survey availability is never identical worldwide. This article explains the operational reasons rather than treating regional differences as a personal failure."],
  ["survey-profile-tips-for-accurate-matching", "Survey Profile Tips for Accurate Matching", "surveys", "2025-12-22", 6, "How accurate profile details can make invitations more relevant while supporting privacy-conscious choices.", "A complete profile can help a panel identify relevant invitations, but that does not mean sharing every piece of information without thought. Aim for accuracy and proportion."],
  ["how-to-read-survey-terms", "How to Read Terms on a Survey Website", "surveys", "2025-12-15", 8, "Find the terms that describe rewards, account closures, privacy, and dispute processes.", "Terms can be long, but a few sections have an outsized effect on your experience. Learn where to look before you create an account."],
  ["common-mistakes-with-survey-websites", "Common Mistakes People Make With Paid Survey Websites", "surveys", "2025-12-10", 7, "Avoid avoidable problems such as duplicate accounts, rushed answers, and missed redemption rules.", "Many survey frustrations are preventable. This guide focuses on process habits that keep your account information, expectations, and records in order."],

  ["how-rewards-points-work", "How Rewards Points Work", "rewards", "2026-01-17", 8, "Understand point values, redemption catalogs, and the terms behind a rewards balance.", "Points can be useful, but the number in an account is only meaningful in the context of the program’s actual redemption rules."],
  ["recognize-legitimate-rewards-programs", "How to Recognize Legitimate Online Rewards Programs", "rewards", "2026-01-14", 8, "A careful way to assess program information, support options, and redemption transparency.", "A legitimate-looking offer still deserves a closer look. Learn which published details can help you assess an online rewards program."],
  ["understanding-minimum-payouts", "Understanding Minimum Payouts", "rewards", "2026-01-09", 7, "How minimum redemption thresholds shape the practical value of a reward balance.", "A low-looking task reward may take longer to access than expected when a program has a threshold. This guide shows how to factor that into a comparison."],
  ["how-to-compare-reward-programs", "How to Compare Reward Programs", "rewards", "2026-01-03", 9, "Compare availability, rewards, expiry, support, and privacy without relying on a single headline.", "The best program is not necessarily the one with the flashiest offer. A structured comparison helps surface the terms that will matter later."],
  ["gift-cards-and-digital-rewards", "Gift Cards and Digital Rewards: What to Check", "rewards", "2025-12-30", 7, "Delivery, region restrictions, expiry, and account requirements for digital redemptions.", "Digital rewards can be convenient, but a specific gift card might not work in every country or on every account. Read the reward detail before redeeming."],
  ["rewards-expiration-policies", "Rewards Expiration Policies Explained", "rewards", "2025-12-20", 7, "Why some programs expire points and how to understand activity requirements.", "Expiry rules should never be a surprise. Here is how to find them, record them, and ask clear questions if the policy is unclear."],
  ["how-referral-programs-work", "How Referral Programs Work", "rewards", "2025-12-12", 7, "What qualifying referrals are, how disclosures help, and why conditions matter.", "Referral programs can be part of a rewards strategy, but they often have detailed conditions. Explain them plainly if you share a link with someone."],
  ["what-is-a-gpt-rewards-platform", "What Is a GPT Rewards Platform?", "rewards", "2025-12-07", 8, "A neutral guide to ‘get-paid-to’ reward models, offers, and practical checks.", "GPT is a broad label used for some reward platforms. Understand the activity, the source of the reward, and the completion terms before participating."],

  ["online-earning-for-beginners", "Online Earning: What Beginners Should Know", "online-earning", "2026-01-16", 10, "A realistic orientation to online work, rewards, testing, research, and skill-based services.", "Online earning is not one category of opportunity. This beginner guide separates occasional reward activities from ongoing skill-based work and explains why expectations matter."],
  ["freelancing-basics-before-your-first-client", "Freelancing Basics Before Your First Client", "online-earning", "2026-01-11", 9, "How to think about services, scope, payment terms, and communication before offering work online.", "Freelancing is a service business, not simply a list of gigs. A clear offer and practical boundaries are more useful than broad promises."],
  ["how-website-testing-opportunities-work", "How Website Testing Opportunities Work", "online-earning", "2026-01-06", 8, "What user testing may involve, why researchers recruit selectively, and what to prepare.", "Website testing typically asks participants to complete tasks and share observations. Opportunities can depend on a study’s audience, device, language, and schedule."],
  ["research-studies-online-explained", "Online Research Studies Explained", "online-earning", "2026-01-01", 8, "How structured research studies can differ from short surveys and task platforms.", "Research studies often have specific consent, eligibility, and participation requirements. Knowing the difference can help you decide whether an invitation is a good fit."],
  ["digital-services-you-can-offer-online", "Digital Services You Can Offer Online", "online-earning", "2025-12-26", 9, "A grounded look at turning an existing skill into a defined online service.", "From proofreading to design support, online services work best when the deliverable, turnaround, and communication process are clear."],
  ["common-online-earning-scams", "Common Online Earning Scams", "online-earning", "2025-12-19", 10, "Spot pressure tactics, payment requests, impersonation, and vague job descriptions.", "Scams often exploit the understandable desire for flexible work. Learn the signals that should make you pause, verify, and avoid sharing information."],
  ["how-to-evaluate-online-opportunities", "How to Evaluate Online Earning Opportunities", "online-earning", "2025-12-14", 8, "A fair checklist for eligibility, compensation, time, support, privacy, and terms.", "Evaluation is not about finding a universal winner. It is about identifying what is clearly explained and whether it fits your own available time and needs."],
  ["online-earning-record-keeping", "Simple Record Keeping for Online Earning Activities", "online-earning", "2025-12-06", 7, "Track time, payouts, requests, and notes without turning it into a complicated project.", "A small record can help you understand the activity you are doing online, particularly where pending rewards or varied payment methods are involved."],
  ["understanding-affiliate-links", "Understanding Affiliate Links", "online-earning", "2025-11-29", 7, "What affiliate links are, why disclosures matter, and how to assess a recommendation.", "Affiliate relationships are common online. A clear disclosure lets readers know when a publisher may be compensated after a qualifying action."],
  ["how-to-spot-unrealistic-income-claims", "How to Spot Unrealistic Income Claims", "online-earning", "2025-11-21", 8, "Why simple headline figures often leave out eligibility, time, costs, and demand.", "A number without context can be misleading. Learn to ask what work was done, for how long, under what conditions, and whether the result is typical."],

  ["paid-surveys-vs-microtasks", "Paid Surveys vs. Microtasks: What’s the Difference?", "microtasks", "2026-01-13", 9, "Compare research questionnaires and small task work by purpose, availability, and payment structure.", "Surveys and microtasks can both happen online, but they serve different purposes. Understanding the distinction makes descriptions and expectations clearer."],
  ["what-are-microtasks", "What Are Microtasks?", "microtasks", "2026-01-07", 8, "A plain-language explanation of common task types and how platforms organize them.", "Microtasks are short actions that contribute to a larger workflow. They may be useful to understand, but availability and requirements vary widely."],
  ["microtask-qualification-requirements", "Microtask Qualification Requirements", "microtasks", "2026-01-02", 7, "Why language, quality checks, location, and training can affect task access.", "Qualification requirements are a normal way platforms match work to participants. Knowing what they are can prevent assumptions about task availability."],
  ["understanding-microtask-payment-models", "Understanding Microtask Payment Models", "microtasks", "2025-12-27", 8, "Per-task rates, approved work, batches, and pending periods explained.", "A listed task payment is only one piece of a payment model. This guide covers acceptance, review, and the importance of reading payment terms."],
  ["microtask-time-management", "Microtask Time Management", "microtasks", "2025-12-18", 7, "Use simple time checks to understand instructions, task flow, and breaks.", "Short tasks can encourage rushing. A basic time check helps you avoid confusing activity with a well-understood commitment."],
  ["microtask-privacy-and-security", "Microtask Privacy and Security Basics", "microtasks", "2025-12-09", 8, "Protect accounts, understand data rules, and keep sensitive information out of task work.", "Task work should never require careless sharing of credentials or personal information. This guide sets out simple security questions to ask first."],
  ["how-to-read-microtask-instructions", "How to Read Microtask Instructions", "microtasks", "2025-12-03", 7, "A repeatable way to approach examples, accuracy standards, and unclear directions.", "Clear instructions are essential for useful task work. Learn how to review them before you commit time to a batch."],
  ["why-microtasks-vary-by-country", "Why Microtask Availability Varies by Country", "microtasks", "2025-11-25", 7, "How client needs, language, payment access, and platform policies affect availability.", "Different availability is a feature of a global task market, not a measure of a participant’s ability. Here are the reasons it can happen."],

  ["how-cashback-websites-work", "How Cashback Websites Work", "cashback", "2026-01-19", 9, "A step-by-step look at qualifying links, tracking, pending periods, and redemptions.", "Cashback can appear simple at checkout, but it relies on eligibility rules and a confirmation process. This guide explains the full path from click to payment."],
  ["cashback-tracking-explained", "Cashback Tracking Explained", "cashback", "2026-01-04", 8, "Cookies, browser sessions, competing extensions, and why a purchase can fail to track.", "Tracking depends on a specific path between a program and retailer. Knowing what may interrupt that path helps you shop more deliberately."],
  ["cashback-exclusions-to-check", "Cashback Exclusions to Check Before You Buy", "cashback", "2025-12-29", 7, "Look beyond the headline percentage to categories, codes, taxes, and return rules.", "Cashback offers have important details. An exclusions list may be the most valuable section to read before you assume a reward will apply."],
  ["why-cashback-is-pending", "Why Cashback Is Pending", "cashback", "2025-12-24", 7, "Why retailer confirmation, cancellations, and returns can affect a reward timeline.", "Pending cashback is often part of the normal process rather than a sign that something is wrong. Learn what to record and when to ask support."],
  ["cashback-and-returns", "Cashback and Returns: What Usually Happens", "cashback", "2025-12-16", 7, "How returns, exchanges, and order changes can affect qualifying purchase rewards.", "A returned or amended order may no longer meet the original offer conditions. The exact result depends on the retailer and the cashback program’s terms."],
  ["browser-extensions-and-cashback", "Browser Extensions and Cashback: Helpful Checks", "cashback", "2025-12-11", 8, "How to review extension permissions, alerts, and competing tracking tools.", "Extensions can make offers easier to find, but they also need appropriate permissions. Read the browser-store listing and understand what an extension does."],
  ["cashback-payout-methods", "Cashback Payout Methods Explained", "cashback", "2025-12-04", 7, "Compare the delivery, thresholds, and geographic availability of common payout options.", "The way a program pays matters as much as the earning rate. Check whether an available payout option works where you live before building a balance."],
  ["cashback-without-overspending", "How to Use Cashback Without Overspending", "cashback", "2025-11-26", 8, "Keep cashback in its proper place: a possible extra on a planned purchase.", "A reward should not become the reason for a purchase. Use a short decision process to keep price, need, and return policies in view."],

  ["create-simple-monthly-budget", "How to Create a Simple Monthly Budget", "personal-finance", "2026-01-20", 10, "A flexible, general-information approach to listing income, commitments, and everyday spending.", "A budget is a planning tool, not a test of perfection. Start with a clear view of your regular money flow, then update it as your circumstances change."],
  ["reduce-unnecessary-subscriptions", "How to Reduce Unnecessary Subscriptions", "personal-finance", "2026-01-14", 8, "A calm review process for recurring services, renewal dates, and alternatives.", "Subscriptions can be useful, but they are easy to forget. A scheduled review can help you decide what still earns its place in your monthly spending."],
  ["digital-payment-safety-basics", "Digital Payment Safety Basics", "personal-finance", "2026-01-08", 9, "Security habits for payments, account alerts, merchant checks, and device access.", "Online payments are routine, but they deserve simple safeguards. This guide focuses on practical steps without assuming a single service or country."],
  ["understanding-common-banking-fees", "Understanding Common Banking Fees", "personal-finance", "2026-01-02", 8, "General education on account, transfer, card, currency, and withdrawal fees.", "Fees vary by service and region. Learn the questions that can help you understand a schedule of charges before it affects your balance."],
  ["healthy-money-habits", "Building Healthy Money Habits", "personal-finance", "2025-12-23", 8, "Small routines for tracking, planning, reviewing, and adjusting your finances.", "Healthy habits are personal and adaptable. This article offers general prompts you can use to build a routine that respects your circumstances."],
  ["how-to-protect-your-information-online", "How to Protect Your Personal Information Online", "personal-finance", "2025-12-17", 9, "A practical checklist for passwords, phishing, privacy settings, and account monitoring.", "Personal information is valuable. Layered security habits can reduce avoidable risk across survey accounts, shopping sites, and financial services."],
  ["managing-online-subscription-renewals", "Managing Online Subscription Renewals", "personal-finance", "2025-12-13", 7, "Use dates, reminders, and terms to stay ahead of free trials and recurring charges.", "Renewal choices are easier when you know the date, price, cancellation route, and what happens to your account after you cancel."],
  ["banking-basics-for-everyday-life", "Banking Basics for Everyday Life", "personal-finance", "2025-12-05", 10, "A general overview of account terms, transaction records, security, and comparisons.", "Banking products and protections vary by location. This educational overview highlights the questions to ask when reading information from a provider."],
  ["how-to-track-online-rewards", "How to Track Online Rewards", "personal-finance", "2025-11-28", 7, "A low-effort record keeping system for points, pending payments, and redemption dates.", "A small reward record can make it easier to spot missing credits and keep email confirmations organized without relying on memory."],
  ["questions-before-joining-rewards-platform", "Questions to Ask Before Joining an Online Rewards Platform", "personal-finance", "2025-11-20", 8, "A broad checklist covering eligibility, privacy, rewards, fees, and support.", "Before signing up, the right questions can tell you whether a rewards platform is clear enough for you to make an informed decision."],
].map(([slug, title, category, date, minutes, excerpt, intro]) => ({
  slug: String(slug),
  title: String(title),
  category: category as Category["slug"],
  date: String(date),
  minutes: Number(minutes),
  excerpt: String(excerpt),
  intro: String(intro),
}));

export const articles: Article[] = drafts.map((draft) => ({
  ...draft,
  keyPoint: `Availability, eligibility, and terms can change. Check the provider’s current information and choose only what fits your circumstances.`,
  sections: sectionByCategory[draft.category],
  faq: [
    { question: `What is the practical takeaway from ${draft.title}?`, answer: "Read the current terms, keep expectations realistic, and compare the time, privacy, and redemption details before you participate." },
    { question: "Will this be the same in every country?", answer: "No. Country, language, payment access, local rules, and provider demand can all affect availability and the experience." },
  ],
}));

export const reviews = [
  {
    slug: "how-to-assess-a-survey-platform",
    title: "How We Assess a Survey Platform",
    date: "2026-01-16",
    excerpt: "A transparent example of the questions we ask before publishing a platform overview.",
    overview: "This is a methodology-focused review format, not an endorsement of a particular provider. It shows readers what information should be available before they decide whether any survey platform suits them.",
    offers: "A platform overview should clearly describe the research activity, account requirements, and any rewards it says are available.",
    suitable: "Readers who want a neutral checklist before considering an online survey panel.",
    regions: "Availability should be confirmed with the provider. Country and language eligibility can change.",
    rewards: "Reward options, minimum withdrawal amounts, and processing times should be verified directly with the provider.",
    pros: ["Focuses on published information rather than unverified earnings claims", "Explains why country availability and terms matter", "Uses clear disclosure and safety questions"],
    considerations: ["No platform is suitable for every visitor", "Program details may change after publication", "Participation does not guarantee rewards or survey invitations"],
  },
  {
    slug: "how-to-assess-a-cashback-program",
    title: "How We Assess a Cashback Program",
    date: "2026-01-09",
    excerpt: "A reader-first framework for cashback terms, tracking, pending periods, and payout details.",
    overview: "Cashback programs deserve a close look at their current retailer terms and how they track qualifying purchases. This format explains the details we expect a useful platform review to cover.",
    offers: "A clear overview should explain its eligible retailers, tracking method, exclusions, pending process, and payout choices.",
    suitable: "Readers comparing a cashback offer against their existing shopping plan — not looking for a reason to spend more.",
    regions: "Retailer lists, currencies, and payout methods may differ by country or region.",
    rewards: "A review should name the published reward structure while linking readers to current terms for confirmation.",
    pros: ["Puts exclusions and returns alongside headline rates", "Highlights transparency and payment accessibility", "Avoids promising a result from any individual purchase"],
    considerations: ["Tracking is not always immediate", "Returns and changes may affect rewards", "A rate can vary by retailer and product category"],
  },
  {
    slug: "how-to-assess-a-microtask-service",
    title: "How We Assess a Microtask Service",
    date: "2025-12-19",
    excerpt: "What to look for in task instructions, quality rules, qualifications, support, and payment terms.",
    overview: "A microtask review needs to explain the work itself before it talks about rewards. This framework helps readers look for instructions, acceptance rules, support options, and data-handling information.",
    offers: "A useful platform description should identify typical task types, qualification processes, quality expectations, and payment model.",
    suitable: "Readers who want to understand task work before deciding whether to spend time on a platform.",
    regions: "Task access can depend on language, location, client demand, and payment availability.",
    rewards: "Published payment rules and any withdrawal threshold should be checked directly with the provider.",
    pros: ["Separates task availability from earnings claims", "Encourages review of privacy and quality rules", "Makes access limitations visible"],
    considerations: ["Task volume can change", "Acceptance processes may affect payable work", "Qualification requirements are not universal"],
  },
];

export const navigation = [
  { href: "/", label: "Home" },
  { href: "/surveys", label: "Surveys" },
  { href: "/rewards", label: "Rewards" },
  { href: "/online-earning", label: "Online Earning" },
  { href: "/microtasks", label: "Microtasks" },
  { href: "/cashback", label: "Cashback" },
  { href: "/personal-finance", label: "Personal Finance" },
  { href: "/reviews", label: "Reviews" },
  { href: "/guides", label: "Guides" },
  { href: "/blog", label: "Blog" },
];

export function getArticlesForCategory(category: Category["slug"]) {
  return articles.filter((article) => article.category === category).sort((a, b) => b.date.localeCompare(a.date));
}
export function getArticle(slug: string) { return articles.find((article) => article.slug === slug); }
export function getRelatedArticles(article: Article) { return getArticlesForCategory(article.category).filter((item) => item.slug !== article.slug).slice(0, 3); }
export function formatDate(date: string) { return new Intl.DateTimeFormat("en", { month: "long", day: "numeric", year: "numeric", timeZone: "UTC" }).format(new Date(`${date}T00:00:00Z`)); }
