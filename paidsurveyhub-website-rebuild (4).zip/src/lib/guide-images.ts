/**
 * Stable remote editorial photos used by guide cards and article headers.
 * Keeping these as HTTPS URLs means Netlify does not need local binary files
 * in the Git repository to build the application.
 */
export const guideImageByCategory: Record<string, string> = {
  surveys: "https://images.pexels.com/photos/6958506/pexels-photo-6958506.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=750&w=1200",
  rewards: "https://images.pexels.com/photos/8937450/pexels-photo-8937450.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=750&w=1200",
  "online-earning": "https://images.pexels.com/photos/9907954/pexels-photo-9907954.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=750&w=1200",
  microtasks: "https://images.pexels.com/photos/8547193/pexels-photo-8547193.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=750&w=1200",
  cashback: "https://images.pexels.com/photos/5717969/pexels-photo-5717969.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=750&w=1200",
  "personal-finance": "https://images.pexels.com/photos/5900074/pexels-photo-5900074.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=750&w=1200",
};

export const homeEditorialWorkspace = "https://images.pexels.com/photos/5912197/pexels-photo-5912197.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400";
