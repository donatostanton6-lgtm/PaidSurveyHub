import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/inter";
import "@fontsource-variable/manrope";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { BackToTop } from "@/components/back-to-top";
import { SITE_URL } from "@/lib/content";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: "PaidSurveyHub — Surveys, Rewards, Cashback & Online Earning Guides", template: "%s | PaidSurveyHub" },
  description: "Explore practical guides and reviews covering paid surveys, rewards programs, cashback, microtasks, online earning opportunities, and personal finance.",
  alternates: { canonical: "/" },
  openGraph: { type: "website", siteName: "PaidSurveyHub", locale: "en_US" },
  twitter: { card: "summary_large_image" },
  robots: { index: true, follow: true },
};

const themeScript = `(() => { try { const t = localStorage.getItem('psh-theme') || 'system'; document.documentElement.dataset.theme = t; } catch {} })()`;
export default function RootLayout({ children }: { children: ReactNode }) {
  const structuredData = { "@context": "https://schema.org", "@graph": [{ "@type": "Organization", name: "PaidSurveyHub", url: SITE_URL, email: "support@paidsurveyhub.com", description: "Independent guides and educational resources covering paid surveys, rewards, online earning, cashback, and personal finance." }, { "@type": "WebSite", name: "PaidSurveyHub", url: SITE_URL, potentialAction: { "@type": "SearchAction", target: `${SITE_URL}/search?q={search_term_string}`, "query-input": "required name=search_term_string" } }] };
  return <html lang="en" suppressHydrationWarning><head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head><body><SiteHeader /><main>{children}</main><SiteFooter /><BackToTop /><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} /></body></html>;
}
