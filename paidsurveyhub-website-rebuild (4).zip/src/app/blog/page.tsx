import { ArticleCard } from "@/components/article-card";
import { Breadcrumbs } from "@/components/breadcrumbs";
import { articles } from "@/lib/content";
import { pageMetadata } from "@/lib/seo";
export const metadata = pageMetadata("Blog", "Original practical articles about surveys, rewards, cashback, microtasks, online earning, and smarter money habits.", "/blog");
export default function BlogPage() { const sorted = [...articles].sort((a,b) => b.date.localeCompare(a.date)); return <><section className="page-hero"><div className="shell"><Breadcrumbs items={[{label:"Blog"}]} /><p className="eyebrow">The PaidSurveyHub desk</p><h1>Practical online rewards &amp; money guides</h1><p className="lead">Original, worldwide-minded articles to help you make sense of online opportunities, privacy, reward terms, and everyday money habits.</p></div></section><section className="section"><div className="shell"><p className="filter-note">{sorted.length} published educational articles · Newest first</p><div className="listing-grid">{sorted.map((article) => <ArticleCard key={article.slug} article={article} />)}</div></div></section></>; }
