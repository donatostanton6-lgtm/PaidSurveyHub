import { Suspense } from "react";
import { SearchClient } from "@/components/search-client";
import { Breadcrumbs } from "@/components/breadcrumbs";
import { pageMetadata } from "@/lib/seo";
export const metadata = pageMetadata("Search", "Search PaidSurveyHub guides, reviews, and categories.", "/search");
export default function SearchPage(){return <><section className="page-hero"><div className="shell"><Breadcrumbs items={[{label:"Search"}]} /><p className="eyebrow">Find a topic</p><h1>Search PaidSurveyHub</h1><p className="lead">Search our guides, review frameworks, and category resources.</p></div></section><section className="prose"><Suspense fallback={<p className="filter-note">Loading search…</p>}><SearchClient /></Suspense></section></>;}
