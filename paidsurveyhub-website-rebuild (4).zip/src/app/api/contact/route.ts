import { DatabaseConfigurationError, getDb, isDatabaseConfigured } from "@/db";
import { contactMessages } from "@/db/schema";

export const runtime = "nodejs";

const databaseMessage = "Form storage is not configured yet. Please email support@paidsurveyhub.com.";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const subject = typeof body.subject === "string" ? body.subject.trim() : "";
    const message = typeof body.message === "string" ? body.message.trim() : "";
    const website = typeof body.website === "string" ? body.website.trim() : "";

    if (website) return Response.json({ message: "Thank you for your message." });
    if (name.length < 2 || !/^\S+@\S+\.\S+$/.test(email) || subject.length < 2 || message.length < 20) {
      return Response.json({ message: "Please complete each field with valid information." }, { status: 400 });
    }
    if (!isDatabaseConfigured()) return Response.json({ message: databaseMessage }, { status: 503 });

    await getDb().insert(contactMessages).values({
      name: name.slice(0, 120),
      email: email.slice(0, 254),
      subject: subject.slice(0, 120),
      message: message.slice(0, 10_000),
    });
    return Response.json({ message: "Thank you — your message has been received." });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) return Response.json({ message: databaseMessage }, { status: 503 });
    return Response.json({ message: "We could not send your message right now. Please email support@paidsurveyhub.com." }, { status: 500 });
  }
}
