import { DatabaseConfigurationError, getDb, isDatabaseConfigured } from "@/db";
import { newsletterSubscriptions } from "@/db/schema";

export const runtime = "nodejs";
const databaseMessage = "Newsletter storage is not configured yet. Please try again later.";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    if (!/^\S+@\S+\.\S+$/.test(email)) return Response.json({ message: "Please enter a valid email address." }, { status: 400 });
    if (!isDatabaseConfigured()) return Response.json({ message: databaseMessage }, { status: 503 });

    await getDb().insert(newsletterSubscriptions).values({ email: email.slice(0, 254) }).onConflictDoUpdate({
      target: newsletterSubscriptions.email,
      set: { isActive: true, unsubscribedAt: null },
    });
    return Response.json({ message: "Thank you. You’re on the PaidSurveyHub Weekly list." });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) return Response.json({ message: databaseMessage }, { status: 503 });
    return Response.json({ message: "We could not subscribe you right now. Please try again later." }, { status: 500 });
  }
}
