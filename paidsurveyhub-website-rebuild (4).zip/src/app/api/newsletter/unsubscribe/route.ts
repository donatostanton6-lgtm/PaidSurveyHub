import { eq } from "drizzle-orm";
import { DatabaseConfigurationError, getDb, isDatabaseConfigured } from "@/db";
import { newsletterSubscriptions } from "@/db/schema";

export const runtime = "nodejs";
const databaseMessage = "Newsletter storage is not configured yet. Please email support@paidsurveyhub.com.";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    if (!/^\S+@\S+\.\S+$/.test(email)) return Response.json({ message: "Please enter a valid email address." }, { status: 400 });
    if (!isDatabaseConfigured()) return Response.json({ message: databaseMessage }, { status: 503 });

    await getDb().update(newsletterSubscriptions).set({ isActive: false, unsubscribedAt: new Date() }).where(eq(newsletterSubscriptions.email, email.slice(0, 254)));
    return Response.json({ message: "Your newsletter preference has been updated." });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) return Response.json({ message: databaseMessage }, { status: 503 });
    return Response.json({ message: "We could not process this request. Please email support@paidsurveyhub.com." }, { status: 500 });
  }
}
