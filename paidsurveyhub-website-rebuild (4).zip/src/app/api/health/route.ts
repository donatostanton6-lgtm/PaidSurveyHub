import { sql } from "drizzle-orm";
import { DatabaseConfigurationError, getDb, isDatabaseConfigured } from "@/db";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  if (!isDatabaseConfigured()) {
    return Response.json({ ok: false, database: "not_configured", message: "DATABASE_URL is required for database-backed forms." }, { status: 503 });
  }

  try {
    await getDb().execute(sql`select 1`);
    return Response.json({ ok: true, database: "connected" });
  } catch (error) {
    const database = error instanceof DatabaseConfigurationError ? "not_configured" : "unavailable";
    return Response.json({ ok: false, database }, { status: 503 });
  }
}
