import { Breadcrumbs } from "@/components/breadcrumbs";
import { PlatformDirectory } from "@/components/platform-directory";
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Platform Directory", "Explore a neutral directory of survey, rewards, testing, microtask, freelance, and cashback platforms to research further.", "/platforms");

export default function PlatformsPage() {
  return <><section className="page-hero"><div className="shell"><Breadcrumbs items={[{ label: "Platforms" }]} /><p className="eyebrow">Research before you join</p><h1>Platform directory</h1><p className="lead">Twenty established platforms across research, rewards, testing, microtasks, freelancing, and cashback. Use this directory as a starting point for your own research — not as a recommendation or guarantee.</p></div></section><section className="section platform-directory-section"><div className="shell"><div className="platform-directory-heading"><div><p className="section-label">Explore services</p><h2>20 platforms to research carefully</h2></div><p>Always verify current terms, country availability, payment methods, privacy information, and eligibility directly with the provider.</p></div><PlatformDirectory /></div></section></>;
}
