import Link from "next/link";
import { Compass, Home } from "lucide-react";
import { pageMetadata } from "@/lib/seo";
export const metadata = pageMetadata("Page not found", "The page you are looking for is not available.", "/404");
export default function NotFound() { return <section className="not-found"><div className="not-found-orbit orbit-one"></div><div className="not-found-orbit orbit-two"></div><div className="shell not-found-inner"><div className="not-found-mark"><Compass size={39}/></div><p className="eyebrow">404 · Page not found</p><h1>Looks like you’ve taken a wrong turn.</h1><p>The page you’re looking for may have moved or no longer exists. Let’s get you back to useful guides.</p><div><Link href="/" className="button button-dark"><Home size={16}/>Back to Home</Link><Link href="/guides" className="button button-light">Explore Guides</Link></div></div></section>; }
