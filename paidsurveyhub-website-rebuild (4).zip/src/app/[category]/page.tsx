import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CategorySort } from "@/components/category-sort";
import { Breadcrumbs } from "@/components/breadcrumbs";
import { categories, categoryBySlug, getArticlesForCategory } from "@/lib/content";
import { pageMetadata } from "@/lib/seo";

export function generateStaticParams() { return categories.map((category) => ({ category: category.slug })); }
export async function generateMetadata({ params }: { params: Promise<{ category: string }> }): Promise<Metadata> { const { category: slug } = await params; const category = categoryBySlug[slug as keyof typeof categoryBySlug]; return category ? pageMetadata(`${category.name} Guides`, category.description, `/${category.slug}`) : {}; }

export default async function CategoryPage({ params }: { params: Promise<{ category: string }> }) {
  const { category: slug } = await params; const category = categoryBySlug[slug as keyof typeof categoryBySlug]; if (!category) notFound();
  const articles = getArticlesForCategory(category.slug); const categoryLabel = category.slug === "personal-finance" ? "educational guides" : "articles and guides";
  return <>
    <section className="page-hero"><div className="shell"><Breadcrumbs items={[{ label: category.name }]} /><p className="eyebrow">{category.eyebrow}</p><h1>{category.name}</h1><p className="lead">{category.description}</p></div></section>
    <section className="shell category-intro"><div><p>{category.name === "Paid Surveys" ? "Survey research depends on finding specific people for specific studies. That is why invitations, screening questions, and reward options can be inconsistent — especially across countries. Our resources focus on the process behind the offer, the terms that affect your time, and safer habits for sharing information online." : category.name === "Personal Finance" ? "The articles here provide general educational information for a worldwide audience. They are not individualized financial, legal, tax, or investment advice. Product rules, protections, and fees vary by country, so verify current information with the relevant provider." : `There is no single experience with ${category.name.toLowerCase()}. Terms, eligibility, availability, and payment access can change by country and over time. These resources give you useful questions to ask before you participate.`}</p><div className="callout"><strong>Practical note:</strong> Our guides do not promise earnings. Before you join any service, verify current eligibility, fees, rewards, and availability directly with that provider.</div></div><aside className="resource-stack" aria-label="Helpful resources"><Link className="resource-link" href="/blog/how-to-protect-your-information-online">Online privacy and safety <span>→</span></Link><Link className="resource-link" href="/review-methodology">How we evaluate information <span>→</span></Link><Link className="resource-link" href="/affiliate-disclosure">How affiliate disclosure works <span>→</span></Link></aside></section>
    <section className="section section-muted"><div className="shell"><div className="section-head"><div><p className="section-label">{categoryLabel}</p><h2>Explore {category.name}</h2><p>Original resources designed to help you understand the details before taking part.</p></div></div><CategorySort articles={articles} category={category} /></div></section>
    <section className="section"><div className="shell"><div className="section-head"><div><p className="section-label">Common questions</p><h2>{category.name} FAQs</h2></div></div><div className="category-faq">{category.faqs.map((faq) => <article className="faq-card" key={faq.question}><h3>{faq.question}</h3><p>{faq.answer}</p></article>)}</div></div></section>
  </>;
}
