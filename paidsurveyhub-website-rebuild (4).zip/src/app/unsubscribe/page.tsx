import { Breadcrumbs } from "@/components/breadcrumbs";
import { UnsubscribeForm } from "@/components/unsubscribe-form";
import { pageMetadata } from "@/lib/seo";
export const metadata = pageMetadata("Unsubscribe", "Manage your PaidSurveyHub Weekly email preference.", "/unsubscribe");
export default function UnsubscribePage(){return <><section className="page-hero"><div className="shell"><Breadcrumbs items={[{label:"Unsubscribe"}]} /><p className="eyebrow">Email preferences</p><h1>Unsubscribe from PaidSurveyHub Weekly</h1><p className="lead">Enter the email address used to subscribe. We’ll update its newsletter status.</p></div></section><section className="prose"><UnsubscribeForm /></section></>;}
