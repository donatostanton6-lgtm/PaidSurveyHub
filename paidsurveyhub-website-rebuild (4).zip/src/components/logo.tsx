import Link from "next/link";

type Props = { compact?: boolean; className?: string };

export function Logo({ compact = false, className = "" }: Props) {
  return (
    <Link href="/" className={`brand ${className}`} aria-label="PaidSurveyHub home">
      <span className="brand-mark" aria-hidden="true">
        <svg viewBox="0 0 36 36" fill="none" role="img">
          <path d="M18 3.5 29.8 8v8.8c0 7.3-4.7 13.2-11.8 15.7C10.9 30 6.2 24.1 6.2 16.8V8L18 3.5Z" fill="currentColor" opacity=".16" />
          <path d="M18 4.5 29 8.7v8.1c0 6.8-4.3 12.2-11 14.6-6.7-2.4-11-7.8-11-14.6V8.7L18 4.5Z" stroke="currentColor" strokeWidth="2.2" />
          <path d="m12.1 18.2 3.7 3.7 8-8.1" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      {!compact && <span className="brand-name">Paid<span>Survey</span>Hub</span>}
    </Link>
  );
}
