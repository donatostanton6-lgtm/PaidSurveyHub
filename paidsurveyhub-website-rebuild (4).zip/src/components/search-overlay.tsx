"use client";

import Link from "next/link";
import { ArrowRight, Search, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { articles, categories } from "@/lib/content";

type Props = { open: boolean; onClose: () => void };
export function SearchOverlay({ open, onClose }: Props) {
  const [query, setQuery] = useState(""); const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (open) { window.setTimeout(() => inputRef.current?.focus(), 80); } }, [open]);
  useEffect(() => { const close = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); }; window.addEventListener("keydown", close); return () => window.removeEventListener("keydown", close); }, [onClose]);
  const results = useMemo(() => { const needle = query.trim().toLowerCase(); if (!needle) return []; return articles.filter((article) => `${article.title} ${article.excerpt} ${article.category}`.toLowerCase().includes(needle)).slice(0, 5); }, [query]);
  const suggestions = ["Paid surveys", "Cashback", "Privacy", "Microtasks"];
  if (!open) return null;
  return <div className="search-overlay" role="dialog" aria-modal="true" aria-label="Search PaidSurveyHub"><button className="search-scrim" aria-label="Close search" onClick={onClose} /><div className="search-modal"><div className="search-modal-top"><p className="eyebrow">Explore PaidSurveyHub</p><button className="icon-button close-search" onClick={onClose} aria-label="Close search"><X size={20} /></button></div><label className="search-modal-input"><Search size={21} aria-hidden="true" /><input ref={inputRef} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search guides, reviews, and topics" /><kbd>ESC</kbd></label>{query ? <div className="overlay-results"><p className="overlay-caption">{results.length ? "Matching guides" : "No guides found"}</p>{results.map((article) => <Link href={`/blog/${article.slug}`} onClick={onClose} key={article.slug} className="overlay-result"><span className={`mini-art art-${categories.find((category) => category.slug === article.category)?.color}`}></span><span><small>{categories.find((category) => category.slug === article.category)?.name}</small><strong>{article.title}</strong><em>{article.excerpt}</em></span><ArrowRight size={17} /></Link>)}{!results.length && <div className="empty-search"><Search size={21}/><p>Try another phrase or browse a category below.</p></div>}</div> : <div className="search-suggestions"><p className="overlay-caption">Popular searches</p><div>{suggestions.map((suggestion) => <button type="button" key={suggestion} onClick={() => setQuery(suggestion)}>{suggestion}<ArrowRight size={14}/></button>)}</div><Link href="/search" onClick={onClose} className="text-link">Open full search <ArrowRight size={14}/></Link></div>}</div></div>;
}
