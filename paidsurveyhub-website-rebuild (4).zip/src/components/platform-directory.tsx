import { ExternalLink, Info } from "lucide-react";
import { platformCategoryClasses, platforms } from "@/lib/platforms";

type Props = { compact?: boolean };

export function PlatformDirectory({ compact = false }: Props) {
  const list = compact ? platforms.slice(0, 8) : platforms;
  return <div className={`platform-directory ${compact ? "platform-directory-compact" : ""}`}>
    <div className="platform-notice"><Info size={16} /><p><strong>Editorial directory, not endorsements.</strong> These are independent third-party services. Eligibility, rewards, privacy practices, and availability can change by country and over time.</p></div>
    <div className="platform-grid">{list.map((platform) => <article className="platform-card" key={platform.name}><div className="platform-card-top"><span className={`platform-monogram ${platformCategoryClasses[platform.category]}`}>{platform.initials}</span><span className={`platform-type ${platformCategoryClasses[platform.category]}`}>{platform.category}</span></div><h3>{platform.name}</h3><p>{platform.description}</p><a href={platform.url} target="_blank" rel="noopener noreferrer">Visit official site <ExternalLink size={13} /></a></article>)}</div>
  </div>;
}
