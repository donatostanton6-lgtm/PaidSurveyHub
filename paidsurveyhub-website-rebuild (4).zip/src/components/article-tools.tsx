"use client";

import { Check, Copy, Link2, Share2 } from "lucide-react";
import { useEffect, useState } from "react";

type Props = { title: string; headings: string[] };
const anchor = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
export function ArticleTools({ title, headings }: Props) {
  const [progress, setProgress] = useState(0); const [copied, setCopied] = useState(false);
  useEffect(() => { const update = () => { const root = document.documentElement; const total = root.scrollHeight - root.clientHeight; setProgress(total > 0 ? Math.min(100, Math.max(0, (window.scrollY / total) * 100)) : 0); }; update(); window.addEventListener("scroll", update, { passive: true }); window.addEventListener("resize", update); return () => { window.removeEventListener("scroll", update); window.removeEventListener("resize", update); }; }, []);
  async function share() { const url = window.location.href; if (navigator.share) { await navigator.share({ title, url }); return; } await navigator.clipboard.writeText(url); setCopied(true); window.setTimeout(() => setCopied(false), 1800); }
  function TocList() { return <ol>{headings.map((heading) => <li key={heading}><a href={`#${anchor(heading)}`}>{heading}</a></li>)}</ol>; }
  return <><div className="reading-progress" aria-hidden="true"><span style={{ transform: `scaleX(${progress / 100})` }} /></div><aside className="article-rail"><div className="toc-desktop"><p>On this page</p><TocList /></div><button onClick={share} className="share-button"><Share2 size={15} />Share article</button></aside><div className="article-mobile-tools"><details><summary>On this page</summary><TocList /></details><button onClick={share} className="share-button">{copied ? <Check size={15} /> : <Copy size={15} />}{copied ? "Link copied" : "Share article"}</button></div></>;
}
export function headingAnchor(value: string) { return anchor(value); }
