"use client";

import { Laptop, Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";

type Theme = "light" | "dark" | "system";
const modes: { value: Theme; label: string; Icon: typeof Sun }[] = [
  { value: "light", label: "Light", Icon: Sun },
  { value: "dark", label: "Dark", Icon: Moon },
  { value: "system", label: "System", Icon: Laptop },
];

export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>("system");
  const [open, setOpen] = useState(false);
  useEffect(() => { const saved = window.localStorage.getItem("psh-theme") as Theme | null; const next = saved && ["light", "dark", "system"].includes(saved) ? saved : "system"; setTheme(next); document.documentElement.dataset.theme = next; }, []);
  function choose(next: Theme) { setTheme(next); setOpen(false); window.localStorage.setItem("psh-theme", next); document.documentElement.dataset.theme = next; }
  const ActiveIcon = modes.find((item) => item.value === theme)?.Icon ?? Laptop;
  return <div className="theme-control"><button className="icon-button" type="button" onClick={() => setOpen((value) => !value)} aria-label="Choose color theme" aria-expanded={open}><ActiveIcon size={17} strokeWidth={2} /></button>{open && <div className="theme-menu" role="menu" aria-label="Color theme">{modes.map(({ value, label, Icon }) => <button type="button" role="menuitemradio" aria-checked={theme === value} onClick={() => choose(value)} key={value}><Icon size={15} />{label}{theme === value && <span aria-hidden="true">✓</span>}</button>)}</div>}</div>;
}
