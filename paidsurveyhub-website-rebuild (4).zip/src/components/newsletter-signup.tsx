"use client";
import { FormEvent, useState } from "react";

export function NewsletterSignup({ compact = false }: { compact?: boolean }) {
  const [email, setEmail] = useState(""); const [message, setMessage] = useState(""); const [loading, setLoading] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); setLoading(true); setMessage(""); try { const response = await fetch("/api/newsletter", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) }); const result = await response.json(); setMessage(result.message || "Thank you for subscribing."); if (response.ok) setEmail(""); } catch { setMessage("We could not process that request. Please try again later."); } finally { setLoading(false); } }
  return <form className={`newsletter-form ${compact ? "newsletter-compact" : ""}`} onSubmit={submit}><label className="sr-only" htmlFor={compact ? "footer-email" : "newsletter-email"}>Email address</label><input id={compact ? "footer-email" : "newsletter-email"} type="email" required autoComplete="email" placeholder="Your email address" value={email} onChange={(event) => setEmail(event.target.value)} /><button className="button button-dark" disabled={loading}>{loading ? "Sending…" : "Subscribe"}</button>{message && <p className="form-status" role="status">{message}</p>}</form>;
}
