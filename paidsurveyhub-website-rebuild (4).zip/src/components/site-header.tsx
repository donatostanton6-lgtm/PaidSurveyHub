"use client";

import Link from "next/link";
import { Menu, Search, X } from "lucide-react";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { Logo } from "./logo";
import { SearchOverlay } from "./search-overlay";
import { ThemeToggle } from "./theme-toggle";

const links = [
  { href: "/", label: "Home" }, { href: "/surveys", label: "Surveys" }, { href: "/rewards", label: "Rewards" }, { href: "/online-earning", label: "Online Earning" }, { href: "/microtasks", label: "Microtasks" }, { href: "/cashback", label: "Cashback" }, { href: "/personal-finance", label: "Personal Finance" }, { href: "/reviews", label: "Reviews" }, { href: "/platforms", label: "Platforms" },
];

export function SiteHeader() {
  const pathname = usePathname(); const [mobileOpen, setMobileOpen] = useState(false); const [searchOpen, setSearchOpen] = useState(false); const [scrolled, setScrolled] = useState(false);
  useEffect(() => { const update = () => setScrolled(window.scrollY > 8); update(); window.addEventListener("scroll", update, { passive: true }); return () => window.removeEventListener("scroll", update); }, []);
  useEffect(() => { setMobileOpen(false); }, [pathname]);
  return <header className={`site-header ${scrolled ? "is-scrolled" : ""}`}><div className="shell nav-row"><Logo /><nav className="desktop-nav" aria-label="Primary navigation">{links.map((link) => <Link key={link.href} href={link.href} className={pathname === link.href ? "active" : ""}>{link.label}</Link>)}</nav><div className="nav-actions"><button className="header-search" type="button" onClick={() => setSearchOpen(true)} aria-label="Search PaidSurveyHub"><Search size={18} strokeWidth={2.1}/><span>Search</span></button><Link className="guides-button" href="/guides">Guides</Link><ThemeToggle /><button type="button" className="menu-button" aria-label={mobileOpen ? "Close menu" : "Open menu"} aria-expanded={mobileOpen} onClick={() => setMobileOpen((open) => !open)}>{mobileOpen ? <X size={20}/> : <Menu size={21}/>}</button></div></div><div className={`mobile-menu ${mobileOpen ? "is-open" : ""}`} aria-hidden={!mobileOpen}><nav className="shell" aria-label="Mobile navigation">{links.map((link) => <Link key={link.href} href={link.href}>{link.label}</Link>)}<Link href="/guides">Guides</Link><Link href="/platforms">Platforms</Link><Link href="/blog">Blog</Link><Link href="/about">About PaidSurveyHub</Link><Link href="/contact">Contact</Link></nav></div><SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} /></header>;
}
