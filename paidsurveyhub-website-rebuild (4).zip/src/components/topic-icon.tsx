import type { Category } from "@/lib/content";

type Props = { slug: Category["slug"] };

const shared = { fill: "none", stroke: "currentColor", strokeWidth: 2.25, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };

export function TopicIcon({ slug }: Props) {
  const art = {
    surveys: <><rect x="24" y="15" width="32" height="46" rx="6" {...shared}/><path d="M33 15v-4h14v4M32 29h15M32 40h7M32 51h7M45 40l3 3 6-7M45 52l3 3 6-7" {...shared}/></>,
    rewards: <><path d="M19 33h42v28H19zM16 25h48v10H16zM40 25v36M40 25c-9-1-14-5-14-10 0-3 2-5 5-5 5 0 8 7 9 15ZM40 25c9-1 14-5 14-10 0-3-2-5-5-5-5 0-8 7-9 15Z" {...shared}/><path d="m57 16 2 2 3-4" {...shared}/></>,
    "online-earning": <><rect x="15" y="17" width="50" height="34" rx="6" {...shared}/><path d="M30 64h20M40 51v13M24 40l8-8 8 5 12-13M49 24h3v3" {...shared}/><circle cx="24" cy="40" r="2" fill="currentColor"/><circle cx="32" cy="32" r="2" fill="currentColor"/><circle cx="40" cy="37" r="2" fill="currentColor"/><circle cx="52" cy="24" r="2" fill="currentColor"/></>,
    microtasks: <><rect x="17" y="17" width="19" height="19" rx="4" {...shared}/><rect x="44" y="17" width="19" height="19" rx="4" {...shared}/><rect x="17" y="44" width="19" height="19" rx="4" {...shared}/><path d="m49 53 5 5 10-12M25 26h4M25 53h4M52 26h4" {...shared}/></>,
    cashback: <><rect x="15" y="23" width="50" height="35" rx="7" {...shared}/><path d="M15 34h50M24 45h13M51 17c-4-4-10-6-16-5-7 1-12 5-15 11M29 19l-9 4 3 9M30 64c4 3 10 5 16 4 7-1 12-5 15-11M51 61l9-4-3-9" {...shared}/></>,
    "personal-finance": <><path d="M17 62h46M22 62V35h36v27M27 35V22h26v13M32 48h4M44 48h4M32 55h4M44 55h4M34 22v-7h12v7" {...shared}/><path d="m24 29 7-7 7 5 12-13M49 14h3v3" {...shared}/><circle cx="24" cy="29" r="2" fill="currentColor"/><circle cx="31" cy="22" r="2" fill="currentColor"/><circle cx="38" cy="27" r="2" fill="currentColor"/><circle cx="50" cy="14" r="2" fill="currentColor"/></>,
  }[slug];

  return <svg viewBox="0 0 80 80" aria-hidden="true" focusable="false">{art}</svg>;
}
