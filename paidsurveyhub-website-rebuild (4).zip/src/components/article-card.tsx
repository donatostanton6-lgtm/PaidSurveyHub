import Image from "next/image";
import Link from "next/link";
import { BadgePercent, BriefcaseBusiness, ClipboardList, Gift, Landmark, ListChecks } from "lucide-react";
import { Article, categoryBySlug, formatDate, guideImageByCategory } from "@/lib/content";

const icons = { surveys: ClipboardList, rewards: Gift, "online-earning": BriefcaseBusiness, microtasks: ListChecks, cashback: BadgePercent, "personal-finance": Landmark };

export function ArticleCard({ article, featured = false }: { article: Article; featured?: boolean }) {
  const category = categoryBySlug[article.category]; const Icon = icons[article.category];
  return <article className={`article-card ${featured ? "featured-card" : ""}`}>
    <Link href={`/blog/${article.slug}`} className={`article-art art-${category.color}`} aria-label={`Read ${article.title}`}>
      <Image className="article-art-image" src={guideImageByCategory[article.category]} alt={`${category.name} guide photo`} fill sizes={featured ? "(max-width: 760px) 100vw, 55vw" : "(max-width: 760px) 100vw, (max-width: 1020px) 50vw, 33vw"} />
      <span className="article-art-overlay"></span><span className="article-visual-icon"><Icon size={30} strokeWidth={1.65}/></span><span className="article-visual-word">{category.name.split(" ")[0]}</span><span className="art-label">{category.name}</span>
    </Link>
    <div className="article-copy"><div className="card-meta"><Link href={`/${article.category}`}>{category.name}</Link><span>·</span><time dateTime={article.date}>{formatDate(article.date)}</time><span>·</span><span>{article.minutes} min read</span></div><h3><Link href={`/blog/${article.slug}`}>{article.title}</Link></h3><p>{article.excerpt}</p><Link className="text-link" href={`/blog/${article.slug}`}>Read guide <span aria-hidden="true">→</span></Link></div>
  </article>;
}
