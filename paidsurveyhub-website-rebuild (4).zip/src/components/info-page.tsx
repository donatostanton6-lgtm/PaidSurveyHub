import { ReactNode } from "react";
import { Breadcrumbs } from "./breadcrumbs";
export function InfoPage({ eyebrow, title, lead, children }: { eyebrow: string; title: string; lead: string; children: ReactNode }) { return <><section className="page-hero"><div className="shell"><Breadcrumbs items={[{label:title}]} /><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="lead">{lead}</p></div></section><article className="prose">{children}</article></>; }
