import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

export class DatabaseConfigurationError extends Error {
  constructor() {
    super("DATABASE_URL is not configured");
    this.name = "DatabaseConfigurationError";
  }
}

type DatabaseClient = ReturnType<typeof drizzle>;

const globalForDb = globalThis as typeof globalThis & {
  __paidSurveyHubPool?: Pool;
  __paidSurveyHubDb?: DatabaseClient;
};

export function isDatabaseConfigured() {
  return Boolean(process.env.DATABASE_URL);
}

/**
 * Creates a database client only when a route handler actually needs one.
 * This keeps static pages and Netlify's build adapter safe when a production
 * database has not been configured yet.
 */
export function getDb(): DatabaseClient {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) throw new DatabaseConfigurationError();

  if (!globalForDb.__paidSurveyHubPool) {
    globalForDb.__paidSurveyHubPool = new Pool({
      connectionString: databaseUrl,
      // A small per-instance pool is safer for serverless function scaling.
      max: 1,
      idleTimeoutMillis: 10_000,
      connectionTimeoutMillis: 5_000,
    });
  }

  if (!globalForDb.__paidSurveyHubDb) {
    globalForDb.__paidSurveyHubDb = drizzle(globalForDb.__paidSurveyHubPool);
  }

  return globalForDb.__paidSurveyHubDb;
}
